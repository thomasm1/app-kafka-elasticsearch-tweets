package xyz.cryptomaven.app.cli;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CliApplicationTests {

	@Test
	void contextLoads() {
	}

}
